from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime
import calendar
import random

# Dashboard view
def Dashboard(request):
    return render(request, 'dash.html')


# Room Graph View
def room_graph_view(request):
    # Generate room numbers dynamically: 101 to 509
    room_numbers = []
    for floor in range(1, 6):  # Floors 1 to 5
        for room in range(1, 10):  # Rooms 1 to 9
            room_number = f"{floor}0{room}"
            room_numbers.append(room_number)

    # Selected room (from dropdown or default)
    selected_room = request.GET.get('room', room_numbers[0])

    # Simulated room data (replace with real DB data later)
    floor = int(selected_room[0])
    current_status = random.choice(["Empty", "Rented", "Maintenance"])

    # Get current date info
    today = datetime.today()
    year = today.year
    month = today.month
    days_in_month = calendar.monthrange(year, month)[1]

    # Generate dummy monthly data (y-axis: signal hour)
    dates = list(range(1, days_in_month + 1))
    hourly_data = [random.randint(0, 23) for _ in dates]

    # Generate dummy daily binary data (24-hour: 0 = empty, 1 = rented)
    daily_binary_data = [random.choice([0, 1]) for _ in range(24)]

    context = {
        "room_numbers": room_numbers,
        "selected_room": selected_room,
        "room_info": {
            "room_number": selected_room,
            "floor": floor,
            "current_status": current_status,
            "last_signal": today.strftime("%d-%m-%Y %I:%M %p"),
            "signal_duration": "2 hours ago"
        },
        "dates": dates,
        "hourly_data": hourly_data,
        "daily_binary_data": daily_binary_data,
        "month": today.strftime("%B"),
        "year": year,
    }

    return render(request, "room/base.html", context)
